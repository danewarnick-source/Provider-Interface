# Apply the tested fixes to PR #332

Repository: `danewarnick-source/agency-peace-of-mind`

Branch: `cursor/dhhs91172-catalog-ingest-960c`

Reviewed base: `1899bafa81917f8a4e30abf9fd6ee152a2b85f41`

The code and data fixes are complete locally. GitHub rejected the write with HTTP 403, `Resource not accessible by integration`. Nothing was committed, pushed, merged or deployed through this session.

## Prompt for Cursor or Claude Code

Apply the attached `pr332-fixes.patch` to the existing PR #332 branch. Read this handoff and `docs/compliance/dhhs91172/IMPORT_REVIEW.md`. These are tested fixes, not a request to recreate the work.

Fetch the latest PR head and inspect any changes since `1899bafa81917f8a4e30abf9fd6ee152a2b85f41`. Preserve concurrent work. Run `git apply --check` before applying the patch. If it conflicts, reconcile the affected files using the replacement files in this archive and the revised workbook; do not overwrite the branch or force-push.

Verify the import loads exactly 760 parents, 607 elements, 1,367 canonical rows and 85 fact definitions. All 1,693 source rows and all 40 parent columns are preserved. The original header object is removed. Every referenced fact and element parent must resolve. Preserve the workbook's actual 12 Release_Gaps. All rules must remain draft/not_published and canActivate=false.

Run the catalog-loader and publication tests, then the repository typecheck/lint and applicable unit tests. Resolve any integration errors introduced by this patch. Commit and push to the existing PR branch after verification. Do not merge, deploy, invent legal intervals, activate rules, or treat unresolved narrative logic as executable law.

Report the commit, tests, and any remaining gaps. The signup setup gate and complete staff/admin UI still require separate end-to-end verification; this patch corrects the catalog import and its data relationships, not every platform workflow.

## Completed locally

- Deterministic exporter verifies the exact workbook SHA-256 before exporting.
- All 760 parent rows now include the original 40 columns; no source header row.
- Full Requirements, Source_index, Applicability_Facts, Release_Gaps, and design guidance preserved.
- Explicit workbook field mapping; source-linked elements and fact definitions join to parents.
- Original narrative retained in `workbookRow`; uncertain timing and alternatives remain draft blockers.
- Reject duplicate/header rows, orphan elements, mismatched parent/element counts, duplicate source IDs, duplicate facts and unresolved fact references.
- 21 loader/publication tests pass against the corrected files.

## Still to do

1. Apply, typecheck/lint/test in the full repository, commit and push. Full application dependencies were unavailable in the local review workspace.
2. Run CI and inspect the existing draft-catalog UI with the now-loaded catalog.
3. Separately verify required signup setup before staff/client creation/import, including backend enforcement and existing-agency behavior.
4. Keep legal interpretation, per-rule executable conditions and the 12 release gaps unresolved until appropriately reviewed. The encoded pilot fixtures are separate from the full source catalog.

Suggested targeted command:

```bash
node --test --experimental-strip-types src/lib/obligations/draft-rules/catalog-loader.test.ts src/lib/obligations/draft-rules/publication.test.ts
```
